package com.example.sample_onetimegps;

import android.app.Activity;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.model.Document;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static android.content.ContentValues.TAG;
import static java.sql.Types.NULL;
import static java.util.Arrays.asList;

public class FirestoreModule {

    private DocumentReference mDocRef;// = FirebaseFirestore.getInstance().document("OnetimeGPS");
    private int RET;
    private Activity mActivity;

    private ArrayList<GroupData> g;
    FirestoreModule(Activity activity,String uuid) {

        this.mActivity = activity;

        Map<String, Object> dataToSave = new HashMap<String, Object>();
        dataToSave.put("state", 0);

        int res = this.submitData("OnetimeGPS/" + uuid, dataToSave);

        //コレクションリスナー
        //https://firebase.google.com/docs/firestore/query-data/listen?hl=ja#java_2
        CollectionReference cr = FirebaseFirestore.getInstance().collection("OnetimeGPS/"+uuid+"/groups");

        cr.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                List<String> cities = new ArrayList<>();
                g = new ArrayList<GroupData>();
                for (QueryDocumentSnapshot doc : value) {
                    if (doc.get("groupName") != null) {
                        double x,y;
                        ArrayList<String> mem;
                        if(doc.get("x") != null) {
                            x = doc.getDouble("x");
                        }else{
                            x=0;
                        }

                        if(doc.get("y") != null) {
                            y = doc.getDouble("y");
                        }else{
                            y=0;
                        }

                        if(doc.get("member") != null){
                            mem = (ArrayList<String>) doc.get("member");
                        }else{
                            mem = new ArrayList<String>();
                        }
                        GroupData data = new GroupData(doc.getString("groupName"),x,y,mem);
                        g.add(data);
                    }
                }
                //Log.d(TAG, "Current cites in CA: " + g);
            }
        });

        /*
        mDocRef.addSnapshotListener(mActivity, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                /// データが存在する場合に処理を実行。
                if (documentSnapshot.exists()) {
                  System.out.println("TEST:"+documentSnapshot.);
                } else if (e != null) {
                    Log.w(TAG, "Got an exception!", e);
                }
            }
        });*/
    }

    //データを送信するメソッド
    //path:更新するデータのパス
    //data:送信データ
    //戻り値：正常終了-0 失敗-1
    int submitData(String path, Map dataToSave) {

        DocumentReference doc = FirebaseFirestore.getInstance().document(path);

        /// データを保存するとともに，保存が完了した場合に，onCompleteメソッドを実行する。
        doc.set(dataToSave).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // 保存が成功した場合
                    RET = 0;
                } else {
                    // 保存が失敗した場合
                    RET = 1;
                }
            }
        });

        return RET;
    }

    //新しくセッションを立てるメソッド
    //guid:セッションに割り当てるid
    //戻り値:正常終了:0
    //       失敗:1
    int makeSession(String uuid) {
        /// 変数名（String型）と，値（Object型）をセットで保存するデータ構造Mapを使う。
        Map<String, Object> dataToSave = new HashMap<String, Object>();
        dataToSave.put("state", 0);

        int res = this.submitData("OnetimeGPS/" + uuid, dataToSave);

        return res;
    }


    //セッションに登録されているグループ名一覧を取得
    //uuid:セッションに割り当てられているid
    //戻り値:失敗した場合はnull
    ArrayList<String> getGroups(String uuid){

        ArrayList<String> groups = new ArrayList<String>();
        //System.out.println(uuid);

        if(!(g == null)) {
            for (GroupData i : g) {
                groups.add(i.groupName);
                //System.out.println(i.groupName);
            }
            return groups;
        }else{
            return null;
        }
    }

    //立てられたセッションに班の情報を追加する関数
    //uuid     :セッションに割り当てられたid
    //groupId  :グループのID
    //groupName:グループの名前
    //member   :班に所属する生徒の名前
    //戻り値:正常終了:0
    //       引数guidで指定されたセッションがない場合や追加に失敗した場合:1
    int joinSession(String uuid, String groupId, String groupName, ArrayList<String> member) {
        Map<String, Object> dataToSave = new HashMap<String, Object>();
        dataToSave.put("state", 0);
        dataToSave.put("groupName", groupName);
        dataToSave.put("member", member);
        dataToSave.put("x", 0.0);
        dataToSave.put("y", 0.0);

        int res = this.submitData("OnetimeGPS/" + uuid + "/groups/" + groupId, dataToSave);

        return res;
    }

    //セッションを開始する(firestoreのフラグを立てる
    //uuid:開始するセッションのid
    //戻り値:正常終了:0
    //       失敗:1
    int startSession(String uuid) {
        Map<String, Object> dataToSave = new HashMap<String, Object>();
        dataToSave.put("state", 1);

        int res = this.submitData("OnetimeGPS/" + uuid, dataToSave);

        return res;

    }

    //位置情報を更新する
    //uuid:セッションに割り当てられているid
    //groupId:自分のグループのid
    //groupData:グループの情報を管理するクラス(詳細は後述)
    //          緯度、経度の情報のみが入ったもの
    //戻り値:正常終了:0
    //       失敗:1
    int updateLoc(String uuid, String groupId, GroupData groupData) {
        Map<String, Object> dataToSave = new HashMap<String, Object>();
        dataToSave.put("groupName", groupData.groupName);
        dataToSave.put("x", groupData.x);
        dataToSave.put("y", groupData.y);
        dataToSave.put("member",groupData.member);

        int res = this.submitData("OnetimeGPS/" + uuid + "/groups/" + groupId, dataToSave);

        return res;
    }

    //すべての班の位置情報を取得する
    //uuid:セッションに割り当てられているid
    //戻り値:GroupData型の配列(詳細は後述)、何もない場合はnull
    ArrayList<GroupData> getLocs(String uuid) {
        return g;
    }


}

//GroupData型
//FirestoreModule内部のクラス
class GroupData {

    String groupName;//班の名前
    double x;//経度
    double y;//緯度
    ArrayList<String> member;

    //コンストラクタ、フィールドの初期化をする
    public GroupData(String name, double x, double y,ArrayList<String> member) {
        this.groupName = name;
        this.x = x;
        this.y = y;
        this.member = member;
    }

    //コンストラクタ、オーバーロード
    public GroupData(double x, double y) {
        this.x = x;
        this.y = y;
        this.groupName = String.valueOf(NULL);
    }
}

