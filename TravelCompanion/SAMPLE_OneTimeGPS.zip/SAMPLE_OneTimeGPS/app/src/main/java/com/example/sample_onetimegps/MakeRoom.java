package com.example.sample_onetimegps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.AndroidRuntimeException;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.NumberPicker;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.UUID;

public class MakeRoom extends AppCompatActivity {

    private NumberPicker[] numPicker = new NumberPicker[4];
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String data;//guid
    private FirestoreModule fsm;

     /* スレッドUI操作用ハンドラ */
    private Handler mHandler = new Handler();
    /* テキストオブジェクト */
    private Runnable updateText;
    private ArrayAdapter<String> adapter;

    /*
    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(this, 5000);//update time
            //TODO りょーへー
            ArrayList<String> group = fsm.getGroups(data);
            createList(group);
        }
    };*/



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_room);
        data = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
        fsm = new FirestoreModule(MakeRoom.this,data);
        makeQR();
        //createList();
        //update始動
        //handler.post(runnable);
        updateText = new Runnable() {
            public void run() {
                ArrayList<String> s = fsm.getGroups(data);
                if(s == null){
                    s = new ArrayList<String>();
                }
                System.out.println(s);
                adapter = new ArrayAdapter<String>(MakeRoom.this, android.R.layout.simple_list_item_1, s);
                ListView listView = findViewById(R.id.list);
                listView.setAdapter(adapter);
                mHandler.removeCallbacks(updateText);
                mHandler.postDelayed(updateText, 5000);
            }
        };
        mHandler.postDelayed(updateText, 5000);
        handler.post(updateText);

        //コロコロの初期化
        for (int i=0; i<4; i++) {
            numPicker[i] = findViewById(getResources().getIdentifier("rewindTime" + i, "id", getPackageName()));
            numPicker[i].setMaxValue(9);
            numPicker[i].setMinValue(0);
        }
    }

    public void makeQR(){
        int size = 500;//px
        try {
            //QRコードをBitmapで作成
            Bitmap bitmap = (new BarcodeEncoder()).encodeBitmap(data, BarcodeFormat.QR_CODE, size, size);
            //作成したQRコードを画面上に配置
            ImageView imageViewQrCode = (ImageView) findViewById(R.id.displayQR);
            imageViewQrCode.setImageBitmap(bitmap);
        } catch (WriterException e) {
            throw new AndroidRuntimeException("Barcode Error.", e);
        }
    }

    public void createList(ArrayList<String>GroupList){
        //TODO String[] Group =  getGroup(string UUID); 下はサンプル
        /* Stringのやつ
        String[] Group = {"A班","２班","はねだ"};
        ArrayList<String> GroupList = new ArrayList<>();
        for(int i=0;i<Group.length;i++) GroupList.add(Group[i]);
        */
        // TODO ArrayList<String> GroupList = getGroup();
        //ArrayList<String> GroupList = new ArrayList<String>(Arrays.asList("Apple", "Orange", "Melon"));
        if(GroupList!=null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, GroupList);
            ((ListView) findViewById(R.id.list)).setAdapter(adapter);
        }
    }

    public void Back(View v){
        startActivity(new Intent(MakeRoom.this, MainActivity.class));
    }


    public void Next(View v){
        //startActivity(new Intent(MakeRoom.this, Next.class));
        String[] f = new String[4];
        for(int i=0;i<4;++i)f[i]=String.valueOf(numPicker[i].getValue());
        String setTime = String.format("%s%s:%s%s",f[0],f[1],f[2],f[3]);//コロコロ取得
    }

}